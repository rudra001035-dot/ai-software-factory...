```python
# Configuration file
GIT_CONFIG_COMMAND = ["git", "config", "--list"]
```
