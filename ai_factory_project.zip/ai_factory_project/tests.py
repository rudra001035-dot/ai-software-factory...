```python
import unittest
from git_config import get_git_config

class TestGitConfig(unittest.TestCase):
    def test_get_git_config(self):
        config = get_git_config()
        self.assertIsNotNone(config)

if __name__ == "__main__":
    unittest.main()
```