```python
import subprocess

def get_git_config():
    """
    Retrieves the Git configuration.
    """
    try:
        # Execute the Git config command
        output = subprocess.check_output(["git", "config", "--list"])
        return output.decode("utf-8")
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")
        return None

def main():
    config = get_git_config()
    if config:
        print(config)

if __name__ == "__main__":
    main()
```
